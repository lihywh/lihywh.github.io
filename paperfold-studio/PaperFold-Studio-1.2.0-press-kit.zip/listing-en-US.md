# PaperFold Studio: 3D Origami

## Short description

Learn 20 origami models with an interactive, rotatable 3D guide.

## Description

Choose from 20 origami models, including a dog face, corner bookmark, paper dart, pinwheel rosette and fold-up paper bridge. Each lesson shows the paper shape to start with.

Drag the highlighted paper point to control the fold, or play a full demonstration. Pause and look at the paper from another angle. Each step includes a check you can make against your own sheet.

The corner bookmark includes a side close-up, a cutaway view, and separate replays for opening the pocket, tucking the point, and pressing the fold flat.

All 20 lessons work offline. Search for a project or browse by category. Pick up where you left off, mark finished projects, and switch between English and Simplified Chinese. Free to use with no account, ads, or in-app purchases.

## What’s new in 1.2.0

The tuck path appears as the pocket opens. Follow the tip to its double-ring destination and compare both paper walls.
